# Interactive Data Analysis in Python

* Leverage jupyterlab as an interactive platform
* Leverage pandas and sqlite for data access
* Take advantage of cuda for speed calculation
* Lots of library available
